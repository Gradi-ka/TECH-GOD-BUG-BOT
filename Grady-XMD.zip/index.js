import makeWASocket from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import { useSingleFileAuthState } from "@whiskeysockets/baileys";
import fs from "fs";
import pino from "pino";

const { state, saveState } = useSingleFileAuthState("./session.json");

const startBot = async () => {
    const sock = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: true,
        auth: state,
    });

    sock.ev.on("creds.update", saveState);

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.fromMe) return;
        const from = msg.key.remoteJid;
        const body = msg.message.conversation || msg.message.extendedTextMessage?.text;

        if (!body) return;

        if (body.startsWith(".")) {
            const command = body.trim().split(" ")[0].slice(1).toLowerCase();
            switch (command) {
                case "menu":
                    await sock.sendMessage(from, { text: "*Grady XMD Menu:*
- .tagall
- .kick @user
- .kickall
- .left
- .close
- .open
- .fun" });
                    break;
                case "tagall":
                    const metadata = await sock.groupMetadata(from);
                    const participants = metadata.participants.map(p => p.id);
                    await sock.sendMessage(from, {
                        text: "🔔 *Tag de tout le monde :*",
                        mentions: participants
                    });
                    break;
                case "left":
                    await sock.groupLeave(from);
                    break;
                default:
                    await sock.sendMessage(from, { text: `❓ Commande inconnue: .${command}` });
            }
        }
    });
};

startBot();