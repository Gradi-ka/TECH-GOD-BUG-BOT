# 🤖 Grady XMD Bot WhatsApp

Bot WhatsApp multi-commandes pour Termux basé sur Baileys MD.

## 🚀 Lancer sur Termux :

```bash
pkg update && pkg upgrade
pkg install nodejs git -y
git clone https://github.com/ton-lien/grady-xmd
cd grady-xmd
npm install
node index.js
```

Puis scanne le QR avec WhatsApp.

## 👑 Commandes disponibles :

- .menu
- .tagall
- .kick @user (à venir)
- .kickall (à venir)
- .left
- .close (à venir)
- .open (à venir)
- .fun (à venir)